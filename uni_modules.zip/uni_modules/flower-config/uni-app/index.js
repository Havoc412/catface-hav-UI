export function test(){
	console.log("flower-library 生态公共配置库")
}