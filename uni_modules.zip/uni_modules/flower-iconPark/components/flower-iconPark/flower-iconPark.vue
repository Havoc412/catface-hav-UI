<template>
	<view>
		flower-iconPark 多平台 uni-app / uni-app-x 生态图标库 ，构建高质量、统一化、可定义的图标资源
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>