<template>
	<fr-svg @click="onClick" :uuid="`fr-icon-chest-${size}${strokeWidth}${theme}${fill}${strokeLinecap}${strokeLinejoin}`" :width="size" :height="size" :isCache="true" :src="iconSvg" />
</template>
<script>
	// #ifdef UNI-APP-X
	import icons from "../../mixins/icons.uts";
	// #endif
	// #ifndef UNI-APP-X
	import icons from "../../mixins/icons.js";
	// #endif
	/**
	 * @description 《胸部》图标
	 * @tutorial https://www.flowerui.com/documents/flower-icons/icons.html
	 * @property {Number} size 图标大小
	 * @property {Number} strokeWidth 线段粗细
	 * @property {String} theme 图标大小
	 * @property {Array} fill 图标颜色，["外部描边颜色","外部填充颜色","内部描边颜色","内部填充颜色"]
	 * @property {String} strokeLinecap 图标大小
	 * @property {String} strokeLinejoin 图标大小
	 * @event {Function} click 图标点击事件
	 */
	export default {
		mixins: [icons],
		computed: {
			// #ifdef UNI-APP-X
			iconSvg(): string {
			// #endif
			// #ifndef UNI-APP-X
			iconSvg() {
			// #endif
				return `<?xml version="1.0" encoding="UTF-8"?><svg width="${this.size}" height="${this.size}" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.9968 3.5C16.9968 5.76563 16.9968 7.48184 16.9968 8.64861C16.9968 10.3988 16.0333 11.0735 12.4023 12.0065C8.77133 12.9394 7.69632 13.4893 6.84816 15.0995C6.28272 16.1729 6 17.8303 6 20.0715V37.5" stroke="${this.colors(0)}" stroke-width="${this.strokeWidth}" stroke-linecap="${this.strokeLinecap}"/><path d="M34.9416 21.5085C35.1792 24.3854 34.6917 26.8978 33.4792 29.046C32.2667 31.1941 30.126 32.5026 27.0572 32.9716" stroke="${this.colors(0)}" stroke-width="${this.strokeWidth}" stroke-linecap="${this.strokeLinecap}" stroke-linejoin="${this.strokeLinejoin}"/><path d="M13.0587 21.5085C12.82 24.3854 13.3096 26.8978 14.5277 29.046C15.7457 31.1941 17.9038 32.5026 21.0022 32.9716" stroke="${this.colors(0)}" stroke-width="${this.strokeWidth}" stroke-linecap="${this.strokeLinecap}" stroke-linejoin="${this.strokeLinejoin}"/><path d="M13 43.5121C14.3333 41.957 15 40.2662 15 38.4396C15 36.613 15 33.8253 15 30.0764" stroke="${this.colors(0)}" stroke-width="${this.strokeWidth}" stroke-linecap="${this.strokeLinecap}"/><path d="M35 43.5121C33.6667 41.957 33 40.2662 33 38.4396C33 36.613 33 33.8253 33 30.0764" stroke="${this.colors(0)}" stroke-width="${this.strokeWidth}" stroke-linecap="${this.strokeLinecap}"/><path d="M31.0003 3.5C31.0003 5.76563 31.0003 7.48184 31.0003 8.64861C31.0003 10.3988 31.9638 11.0735 35.5948 12.0065C39.2257 12.9394 40.3008 13.4893 41.1489 15.0995C41.7144 16.1729 41.9971 17.8303 41.9971 20.0715V37.5" stroke="${this.colors(0)}" stroke-width="${this.strokeWidth}" stroke-linecap="${this.strokeLinecap}"/></svg>`
			}
		}
	}
</script>